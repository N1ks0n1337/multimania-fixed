import React from 'react'

const LearnMore = () => {
  return (
    <div>LearnMore</div>
  )
}

export default LearnMore