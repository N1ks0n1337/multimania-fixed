import React from 'react'

const Works = () => {
  return (
    <div>How it works?</div>
  )
}

export default Works